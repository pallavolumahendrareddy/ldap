Setup:
1)  Make VirtualEnv and activate the same.
2) pip install -r requirements.txt
3) python manage.py runserver 8001

Service will be up on http://127.0.0.1:8001

Usage:
Ldap Service: http://127.0.0.1:8001/ldap/

Request Type: POST

Postman Raw body in Json format:
{
  "username":"vk00497990",
  "password":"Garg1988*"
}

Response
{"country": "India", "username": "vk00497990", "displayname": "Vikas Kumar16", "auth_status": true, "error": ""}


Usage:
SSO Service: http://127.0.0.1:8001/sso/
Request Type: POST
Postman Raw body in Json format:
{
  "Token":"SSO Generated Token"
}

Response
{"country": "India", "username": "vk00497990", "displayname": "Vikas Kumar16", "auth_status": true, "error": ""}


From Python:
install requests
pip install requests

Steps:
import requests
import json
ldap_service ='http://127.0.0.1:8001/ldap/'
user_info = requests.post(ldap_service , json.dumps({'token':ID})).text
user_info = json.loads(user_info)

user_info contain the below python dict:
{"country": "India", "username": "vk00497990", "displayname": "Vikas Kumar16", "auth_status": true, "error": ""}


