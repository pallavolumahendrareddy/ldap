class user_details(object):

    def __init__(self):
        self.auth_status = False
        self.username = ""
        self.displayname = ""
        self.country = ""
        self.error = ""

    def get_auth_status(self):
        return self.auth_status

    def set_auth_status(self, value):
        self.auth_status = value

    def get_username(self):
        return self.username

    def set_username(self, value):
        self.username = value

    def get_displayname(self):
        return self.displayname

    def set_displayname(self, value):
        self.displayname = value

    def get_country(self):
        return self.country

    def set_country(self, value):
        self.country = value

    def get_error(self):
        return self.error

    def set_error(self, value):
        self.error = value
