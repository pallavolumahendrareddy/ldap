from django.http import JsonResponse
from django.shortcuts import render
from ldap3 import Server, Connection
from ldap3.core.exceptions import LDAPException, LDAPBindError
import json
from django.views.decorators.csrf import csrf_exempt
from login.user_details import user_details
from django.conf import settings
from login.form import body_form,token_form,user_details_form
import requests
from django.utils.html import strip_tags


@csrf_exempt
def ldap(request= None):
    # body_unicode = request.body.decode('utf-8')
    # body = json.loads(body_unicode)
    # username = body["username"]
    # password = body["password"]
    body_unicode = {'username': json.loads(request.body.decode('utf-8'))["username"],
                    'password': json.loads(request.body.decode('utf-8'))["password"]}
    body = body_form(body_unicode)
    if body.is_valid():
        username = body.cleaned_data['username']
        password = body.cleaned_data['password']

    user_info = validate_user(username, password)
    return JsonResponse(user_info.__dict__)


@csrf_exempt
def sso(request= None):
    # body_unicode = request.body.decode('utf-8')
    # body = json.loads(body_unicode)
    # token = body["token"]
    body_unicode = {'token': json.loads(request.body.decode('utf-8'))["token"]}
    body = token_form(body_unicode)
    if body.is_valid():
        token = body.cleaned_data['token']

    user_info = validate_sso(token)
    return JsonResponse(user_info.__dict__)

def ldap_connection(username= None, password= None):
    msg = 'connected'
    for domain in settings.LDAP:
        try:
            server = Server(domain['SERVER'], settings.LDAP_PORT,
                            use_ssl=False, get_info=settings.LDAP_INFO)
            conn = Connection(server, user=domain['DOMAIN'] + "\\" + username,
                              password=password, auto_bind=True, version=3,
                              authentication='SIMPLE', client_strategy='SYNC',
                              auto_referrals=True, check_names=True,
                              read_only=False, lazy=False, raise_exceptions=False)
            return conn, msg
        except Exception as e:
            msg = str(e)
    return None, msg

def validate_user(username= None, password= None):

    user_info = user_details()
    conn, status = ldap_connection(username, password)
    try:
        if conn and conn.result['description'] == "success":
            entries = conn.extend.standard.paged_search(
                settings.DISTINGUISHED_NAME,
                '(&(objectClass=person)(SamAccountName={}))'.format(username),
                attributes=settings.ATTRIBUTE)
            for entry in entries:
                response = entry
            user_info = __getuserdetails(username, response)
        else:
            user_info.set_error(status)

    except Exception as e:
        user_info.set_error(str(e))
    return user_info

def validate_sso(token= None):

    try:
        #token = strip_tags(token)
        if strip_tags(token) == token: True
        else: False
        user_info = user_details()
        request_xml = """<?xml version="1.0" encoding="utf-8"?>
               <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                 <soap:Body>
                   <GetEmployeeCode xmlns="http://techmahindra.com/">
                     <Token>""" + token + """</Token>
                   </GetEmployeeCode>
                 </soap:Body>
               </soap:Envelope>"""

        headers = {'Content-Type': 'text/xml'}  # set what your server accepts
        response = requests.post(
            settings.SSO_URL, data=request_xml, headers=headers).text
        root = ET.fromstring(response)
        string = root.findall('.//{http://techmahindra.com/}string')
        string_values = [values.text for values in string]
        user_info.set_auth_status(True)
        user_info.set_username(string_values[2])
        user_info.set_displayname(string_values[1])
        user_info = user_details_service(user_info)
    except Exception as e:
        user_info.set_error(str(e))

    return user_info

def __getuserdetails(username= None, response= None):
    user_info = user_details()
    user_info.set_auth_status(True)
    user_info.set_username(username)
    response_att = response['attributes']
    user_info.set_displayname(response_att['displayName'])
    user_info.set_country(response_att['extensionAttribute9'])
    return user_info


def user_details_service(user_info= None):
    """
      This Service will fetch further user details in case of SSO connect
    """
    try:
        emp_id = user_info.get_username()[2:].lstrip("00")
        f = urllib.request.urlopen(settings.USER_DETAILS_URL + emp_id)
        # data = json.loads(f.read().decode(f.info().get_param('charset') or 'utf-8'))
        # user_info.set_country(data[0]['Current_Country'])
        # if user_info.get_country() not in settings.COUNTRIES:
        #     user_info.set_auth_status(False)
        #     user_info.set_error(settings.LOC_FAIL_MSG)
        # user_info.set_displayname(data[0]['Name'])
        data = {'Current_Country': json.loads(f.read().decode(f.info().get_param('charset') or 'utf-8'))[0]["Current_Country"],
                'Name': json.loads(f.read().decode(f.info().get_param('charset') or 'utf-8'))[0]["Name"]}
        user_details = user_details_form(data)
        if user_details.is_valid():
            user_info.set_country(user_details.cleaned_data['Current_Country'])
            if user_info.get_country() not in settings.COUNTRIES:
                user_info.set_auth_status(False)
                user_info.set_error(settings.LOC_FAIL_MSG)
            user_info.set_displayname(user_details.cleaned_data['Name'])

    except Exception as e:
        user_info.set_error(str(e))
    return user_info
