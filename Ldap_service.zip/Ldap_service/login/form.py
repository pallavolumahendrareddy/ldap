from django import forms


class body_form(forms.Form):
    username = forms.CharField(required=False)
    password = forms.CharField(required=False)

class token_form(forms.Form):
    token = forms.CharField(required=False)

class user_details_form(forms.Form):
    Current_Country = forms.CharField(required=False)
    token = forms.CharField(required=False)

